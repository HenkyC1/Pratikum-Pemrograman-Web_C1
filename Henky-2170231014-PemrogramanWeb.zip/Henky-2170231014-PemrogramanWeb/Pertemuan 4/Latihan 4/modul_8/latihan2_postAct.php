<?php
echo "<center>Nama :".$_GET["nama"]. "</center><br>";
echo "<center>Email :".$_GET["email"]. "</center><br>";
?>