<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tanggalan</title>
</head>
<body>
    <?php 
        echo date("m-F-Y, g:i:s a");
        echo "<br>";
        echo date("d-M-Y, H:i:s");
        echo "<br>";
        echo date("Y-m-d, H:i:s");
        echo "<br>";
        echo date("m-d-Y, H:i:s");
        echo "<br>";
        echo date("d-m-y, g:i");
    ?>
</body>
</html>