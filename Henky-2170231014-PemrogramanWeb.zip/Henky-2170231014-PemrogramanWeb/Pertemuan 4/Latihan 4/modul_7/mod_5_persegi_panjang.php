<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luas Persegi Panjang</title>
    <style>
        .p5{
            padding-top: 5px;
            padding-bottom: 5px;
        }
    </style>
</head>
<body>
<h1>Hitung Luas Persegi Panjang</h1>
    <form action="" method="post">
        <div class="p5">
            <label for="panjang">Panjang : </label>
            <input type="number" name="panjang" required>
        </div>
        <div class="p5">
            <label for="lebar">Lebar : </label>
            <input type="number" name="lebar" required>
        </div>
        <br><br>
        <input type="submit" name="submit" value="Hitung">
    </form>
    
    <?php 
         if(isset($_POST['submit'])){
            $panjang    =$_POST['panjang'];
            $lebar        =$_POST['lebar'];
                   
            $luas_persegi_panjang = $panjang*$lebar;
            $keliling_persegi_panjang = 2*($panjang+$lebar);
                    
            echo "Hasil hitung luas persegi panjang adalah sebagai berikut:<br />";
            echo "Diketahui;<br />";
            echo "Panjang = $panjang<br />";
            echo "Lebar = $lebar<br />";
            echo "Maka luas persegi panjang sama dengan [ $panjang x $lebar ] = $luas_persegi_panjang<br />";
        }
    ?>
</body>
</html>