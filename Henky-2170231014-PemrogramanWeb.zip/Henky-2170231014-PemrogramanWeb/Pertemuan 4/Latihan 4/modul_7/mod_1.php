<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variabel</title>
</head>
<body>
    <?php 
        $nilai_1 = 10;
        $nilai_2 = 3;
        $nilai_3 = 2 * $nilai_1 + 8 * $nilai_2;
        echo "nilai = ", $nilai_3;
        echo "<br>";
        $jumlah = $nilai_1 + $nilai_2;
        echo "hasil dari $nilai_1 + $nilai_2 adalah : $jumlah";
        echo "<br><br>";
        echo "\"Nama : HENKY \" <br>";
        echo "Nim : 2170231014";
    ?>
</body>
</html>