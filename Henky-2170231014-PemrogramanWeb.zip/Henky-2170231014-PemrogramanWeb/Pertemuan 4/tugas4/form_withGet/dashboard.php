<div style="padding:200px;">
    <fieldset>
        <legend>Dashboard</legend>
        <div style="padding:10px;">
            <p>Hello, <?php echo $_GET['name'] ?></p>
            <p>Email : <?php echo $_GET['email'] ?></p>
            <p>Login At : <?php echo date('d F Y, g:i:s a'); ?></p>
        </div>
        <div style="text-align: right">
            <a href="index.php">Login</a>
        </div>
    </fieldset>
</div>