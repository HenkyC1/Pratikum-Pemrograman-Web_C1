<div style="padding:200px;">
<form action="result.php">
    <fieldset>
        <legend>Form Login</legend>
        <div style="padding:5px;">
            <label for="name">Name : </label>
            <input type="name" name="name">
        </div>
        <div style="padding:5px;">
            <label for="email">Email : </label>
            <input type="email" name="email">
        </div>
        <br><br>
        <input type="submit" name="login" value="Login">
    </fieldset>
</form>
</div>