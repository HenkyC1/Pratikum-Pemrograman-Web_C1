<div style="padding:200px;">
    <fieldset>
        <legend>Dashboard</legend>
        <div style="padding:10px;">
            Username dan Email Wajib Di Isi!
        </div>
        <div style="text-align: right">
            <a href="index.php">Login Kembali</a>
        </div>
    </fieldset>
</div>