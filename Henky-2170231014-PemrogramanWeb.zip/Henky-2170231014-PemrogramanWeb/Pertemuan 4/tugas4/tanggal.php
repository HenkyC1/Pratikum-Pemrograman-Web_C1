<!DOCTYPE html>
<html>
<head>
	<title>Tanggalan</title>
</head>
<body>
<?php 
date_default_timezone_set('Asia/Jakarta');
echo date("d-F-Y, H:i:s a");
?>
</body>
</html>