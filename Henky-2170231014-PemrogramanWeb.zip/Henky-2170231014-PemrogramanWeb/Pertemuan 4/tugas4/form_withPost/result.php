<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title></title>
    </head>
    <body>
        <?php 
            
            if ($_POST['name'] == null || $_POST['email'] == null) {
                include 'gagal_login.php';
            } else {
                include 'dashboard.php';
            }
        ?>
    </body>
</html>