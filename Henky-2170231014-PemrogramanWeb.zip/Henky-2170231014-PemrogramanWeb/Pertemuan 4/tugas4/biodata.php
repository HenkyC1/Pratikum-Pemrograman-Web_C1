<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemrograman PHP dengan Array</title>
    <style>
        .p5{
            padding-top: 5px;
            padding-bottom: 5px;
        }
    </style>
</head>
<body>
<h1>Input Biodata</h1>
    <form action="" method="post">
        <div class="p5">
            <label for="name">Name : </label>
            <input type="text" name="name" required>
        </div>
        <div class="p5">
            <label for="gender">Gender : </label>
            <input type="radio" name="gender" id="gender" value="Man"> Man
            <input type="radio" name="gender" id="gender" value="Woman"> Woman
        </div>
        <div class="p5">
            <label for="country">Country : </label>
            <select name="country" id="country" required>
                <option value="Indonesia">Indonesia</option>
                <option value="Singapore">Singapore</option>
                <option value="China">China</option>
            </select>
        </div>
        <div class="p5">
            <label for="email" required>Email : </label>
            <input type="email" name="email" required>
        </div>
        <div class="p5">
            <label for="address" required>Address : </label>
            <textarea name="address" id="" cols="70" rows="8"></textarea>
        </div>
        <br><br>
        <input type="submit" value="Submit">
    </form>
    
    <?php 
        if (isset($_POST["name"])) {
            echo "<hr>";
            echo "<h4>Biodata Anda</h4>";
            echo "Nama : ", $_POST["name"];
            echo "<br>";
            echo "Gender : ", $_POST["gender"];
            echo "<br>";
            echo "Country : ", $_POST["country"];
            echo "<br>";
            echo "Email : ", $_POST["email"];
            echo "<br>";
            echo "Address : ", $_POST["address"];
        }
    ?>
</body>
</html>